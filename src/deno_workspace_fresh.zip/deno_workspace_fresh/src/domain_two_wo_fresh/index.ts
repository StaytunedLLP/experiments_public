import sayHello from "@repo/domain_two_wo_fresh/calc.ts"

export default function App() {
    return `Welcome to domain one without fresh! ${sayHello()}`
}