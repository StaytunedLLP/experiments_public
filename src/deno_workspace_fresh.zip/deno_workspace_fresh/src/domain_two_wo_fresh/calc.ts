export default function sayHello() {
    return "Hello from domain_two_wo_fresh!";
}